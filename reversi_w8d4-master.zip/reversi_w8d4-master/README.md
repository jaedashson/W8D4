# Reversi in JavaScript

Before beginning, install dependencies with: `npm install`.

To play the game, run: `npm start`.

To run the tests, run: `npm test`.
